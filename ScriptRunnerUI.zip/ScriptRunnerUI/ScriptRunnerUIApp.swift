//
//  ScriptRunnerUIApp.swift
//  ScriptRunnerUI
//
//  Created by v.pecheritsya on 03.09.2026.
//

import SwiftUI
import SwiftData

@main
struct ScriptRunnerUIApp: App {
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([Project.self])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
        
        do {
            return try ModelContainer(for: schema, configurations: [modelConfiguration])
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.light)
            
        }
        .modelContainer(sharedModelContainer)
    }
}
